import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
import time

# Set up the driver and other configurations
@pytest.fixture(scope="function")
def driver():
    # Setup for Chrome WebDriver, make sure you have chromedriver installed.
    service = Service(executable_path=r"C:\\Users\\windows\\PycharmProjects\\Selenium Project\\chromedriver.exe")  # Correct path
    driver = webdriver.Chrome(service=service)
    driver.get("https://www.lambdatest.com/selenium-playground/table-sort-search-demo")
    driver.maximize_window()
    yield driver
    driver.quit()

def test_search_functionality(driver):
    # Locate the search box and enter "New York"
    search_box = driver.find_element(By.XPATH, '//div[@id="example_filter"]//*[@type="search"]')
    search_box.clear()
    search_box.send_keys("New York")
    search_box.send_keys(Keys.RETURN)
    time.sleep(2)  # Wait for results to load

    # Validate that the search results contain exactly 5 rows
    rows = driver.find_elements(By.XPATH, "//table[@id='example']/tbody/tr")
    assert len(rows) == 5, f"Expected 5 rows but found {len(rows)}"

    # Validate that all the rows contain "New York"
    for row in rows:
        assert "New York" in row.text, "Expected 'New York' in the row text"

    # Validate the total number of entries displayed in the table
    total_entries = driver.find_element(By.XPATH, "//div[@id='example_info']").text
    assert "24" in total_entries, f"Expected total entries to be 24 but found {total_entries}"
