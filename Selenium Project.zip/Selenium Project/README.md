# Selenium Automation - Search Functionality Test

This project automates the validation of the search functionality for the Table Search Demo on the Selenium Playground website.

## Approach

The script navigates to the Table Search Demo page, locates the search box, and searches for the term "New York". It then validates the following:
1. The search results contain exactly 5 entries.
2. Each result contains the term "New York".
3. The total number of entries in the table is 24.

## Setup Instructions

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
